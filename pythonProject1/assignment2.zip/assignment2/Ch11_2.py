def main():
    m = []

    for j in range(1, 5):
        row = [float(item) for item in input("Enter 4-by-4 matrix row for row  " + str(j) + ":").split()]
        m.append(row)
        j += 1

    major_diagonal = sum(m[i][i] for i in range(len(m)))

    print("Sum of the elements in the major diagonal is ", major_diagonal)


main()

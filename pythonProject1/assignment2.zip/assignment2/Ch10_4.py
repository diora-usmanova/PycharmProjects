score = []
scores = input("Enter scores : ")
items = scores.split()
score = [eval(x) for x in items]
average = sum(score) // len(score)

count = 0
for i in range(len(score)):
    if score[i] >= average:
        count += 1
Count = 0
for j in range(len(score)):
    if score[j] < average:
        Count += 1
print("Average is : ", average)
print("Above average is : ", count)
print("Below average is: ", Count)

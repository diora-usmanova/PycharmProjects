numbers = input("Enter the numbers : ")
listOfNumbers = numbers.split()
numberList = [int(x) for x in listOfNumbers]

d1 = {}
for item in numberList:
    if d1.get(item) is None:
        d1[item] = 1
    else:
        d1[item] += 1
l2 = [[y, x] for (x, y) in d1.items()]
l2.sort(reverse=True)
print(l2)
print("Number", l2[0][1], "appear", l2[0][0], "times")

for i in range(0, len(l2) - 1):
    if l2[i][0] == l2[i + 1][0]:
        print("Number", l2[i + 1][1], "appear", l2[i + 1][0], "times")
    else:
        break

ssn = input("Enter a social security number: ")
if ssn.isalnum():
    print("Invalid SSN")
else:
    print("Valid SSN")


def reverse(s):
    return s[:: -1]


s = []

s = reverse(input("Enter integers : "))
print(s)
